package SalleReunion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import General.Connexion;

public class SalleReunion {
	
	private int id;
	private String nomSalle;
	private int nbSiege;
	
	//CONSTRUCTEURS
	public SalleReunion(int id) {
		this.id = id;
		
	}
	
	
	public SalleReunion (int id, String nomSalle) {
		this.id = id;
		this.nomSalle = nomSalle;
	}
	
	public SalleReunion (int id, String nomSalle, int nbSiege) {
		this.id = id;
		this.nomSalle = nomSalle;
		this.nbSiege = nbSiege;
	}
	
	//GETTERS	
	
	
	public int getId() {
		return this.id;
	}
	
	
	public String getNom() {
		return this.nomSalle;
	}
	
	public int getnbSiege(){
		return this.nbSiege;
	}
	
	//SETTERS
	
	public void setId(int id) {
		this.id= id;
	}
	
	//METHODES
	
	public void getInfoSalleBDD() throws SQLException {
		java.lang.String sql = "SELECT * FROM salle_reunion where id = ? ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id); 
		ResultSet result = pstate.executeQuery(); 
		result.next();
		this.nomSalle = result.getString("nom");
		this.nbSiege = result.getInt("nbsiege");
			
	}
	

}
