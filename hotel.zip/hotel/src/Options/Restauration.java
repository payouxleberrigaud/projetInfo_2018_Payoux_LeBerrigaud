package Options;

public class Restauration  implements IOption{
	int id;
	String description = "restauration";
	String type;
	int prix;
	
	
	public Restauration() {
		
		
	}
	
	public Restauration(String type) {
		// pour rentrer le type de la restauration et affecter le prix en fonction du type 
		//directement quand on instancie l'objet 
		this.type = type;
		if(type == "dejeuner chambre"){ this.prix =  15;
		}
		if(type == "dejeuner restaurant"){ this.prix =  12;
		}
		if(type == "diner chambre"){this.prix = 25;
		}
		else {
		this.prix = 20;}
	}
	
	public int getPrix() {
		return this.prix;
		
		
}
	public String getDescription () {
		return this.description;
	}
}
	
	
