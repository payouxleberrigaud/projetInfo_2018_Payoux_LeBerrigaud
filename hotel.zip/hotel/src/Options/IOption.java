package Options;

public interface IOption {

	public abstract int getPrix();

	public abstract String getDescription();

}
