package Options;

public class Autres implements IOption {
	
	String description;
	int prix;

	//CONSTRUCTEURS
	public Autres(){
	}
	
	public Autres(int id, String description, int prix){
		this.description = description;
		
		this.prix = prix;
		
	}
	//GETTER
	public int getPrix(){
		return this.prix;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
