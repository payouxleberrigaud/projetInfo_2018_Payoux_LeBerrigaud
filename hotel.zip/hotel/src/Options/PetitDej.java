package Options;

public class PetitDej implements IOption {
	
	private String description = "petit déjeuner";
	private String type;
	private int prix;
	
	//CONSTRUCTEUR
	public PetitDej() {
		
	}
	
	public PetitDej(String type) {
		//pour rentrer le type du petit dej et affecter le prix en fonction du type
		//directement quand on instancie l'objet
		this.type = type;
		
		if(type == "chambre"){ this.prix = 17;
		}
		else {
		this.prix = 12;}
	}
	
	//GETTERS
	public String getType(){
			
			return this.type; 
			}
	
	public int getPrix() {
		return this.prix;
	}
	
	public String getDescription() {
		return this.description;
	}
	
}

