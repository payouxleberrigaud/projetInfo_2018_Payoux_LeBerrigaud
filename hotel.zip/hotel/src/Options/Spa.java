package Options;

public class Spa implements IOption {

	int id;
	String description = "seances de 30 minutes au Spa";
	int prix = 15;

	// CONSTRUCTEUR
	public Spa() {

	}

	// GETTERS
	public int getPrix() {
		return this.prix;
	}

	public String getDescription() {
		return this.description;
	}
}
