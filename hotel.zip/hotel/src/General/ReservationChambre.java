package General;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

import Chambre.ChambreDouble;
import Chambre.ChambreSimple;
import Chambre.ChambreComposee;
import Options.Autres;
import Options.IOption;
import Options.PetitDej;
import Options.Restauration;
import Options.Spa;


public class ReservationChambre extends Reservation{
	
	
	private List<ChambreSimple> listChambresSimplesReservees;
	private List<ChambreDouble> listChambresDoublesReservees;
	private List<ChambreComposee> listChambresComposeesReservees;
	
	private String dateDebutReserv;
	private String dateFinReserv;
	private int nbChambresSimples;	
	private int nbChambresDoubles;
	private int nbChambresComposees;
	private ArrayList<IOption> listOptions = new ArrayList<IOption>();
	
	//CONSTRUCTEUR
	
	public ReservationChambre(String type, String dateDSejour, String dateFSejour ,int nbPersonnes, int nbChambresSimples ,int nbChambresDoubles, int nbChambresComposees) throws SQLException {
		
		super (nbPersonnes, type);
		this.nbChambresSimples = nbChambresSimples;
		this.nbChambresDoubles = nbChambresDoubles;
		this.nbChambresComposees = nbChambresComposees;
		this.dateDebutReserv = dateDSejour;
		this.dateFinReserv = dateFSejour;
	}
	
	//GETTERS
	
	public ArrayList<IOption> getOptions(){
		return this.listOptions;
	}
	
	public int getNbChambresSimples() {
		return this.nbChambresSimples;
	}
	public int getNbChambresDoubles() {
		return this.nbChambresDoubles;
	}
	public int getNbChambresComposees() {
		return this.nbChambresComposees;
	}
	
	public String getDateDebut(){
		return this.dateDebutReserv;
	}
	public String getDateFin(){
		return this.dateFinReserv;
	}
	
	//SETTER
	public void setOption(IOption option) {
		this.listOptions.add(option);	
	}
	
	// AUTRES METHODES
	
	//AJOUTER DES OPTIONS A LA RESERVATION
	
	/**
	 * Ajoute des objects PetitDej à listOptions
	 * @param nbPetitDejChambre
	 * @param nbPetitDejRestaurant
	 */
	public void ajouterPetitDej(int nbPetitDejChambre, int nbPetitDejRestaurant) {
		if (nbPetitDejChambre != 0) {
		for (int i = 0; i < nbPetitDejChambre; i++) {
		  PetitDej pd = new PetitDej("chambre");
		  setOption(pd);}}
		if (nbPetitDejRestaurant != 0) {
		for (int i = 0; i < nbPetitDejRestaurant; i++) {
			PetitDej pd = new PetitDej("restaurant");
			setOption(pd);
	}}}
	
	/**
	 * Ajoute des objets Restauration à listOptions
	 * @param nbDejeunerChambre
	 * @param nbDejeunerRestaurant
	 * @param nbDinerChambre
	 * @param nbDinerRestaurant
	 */
	
	public void ajouterRestauration(int nbDejeunerChambre, int nbDejeunerRestaurant, int nbDinerChambre, int nbDinerRestaurant) {
		for (int i = 0; i < nbDejeunerChambre; i++) {
			Restauration rest = new Restauration("dejeuner chambre");
			setOption(rest);
		}
		for (int i = 0; i < nbDejeunerRestaurant; i++) {
			Restauration rest = new Restauration("dejeuner salle");
			setOption(rest);
		}
		for (int i = 0; i < nbDinerChambre; i++) {
			Restauration rest = new Restauration("diner chambre");
			setOption(rest);
		}
		for (int i = 0; i < nbDinerRestaurant; i++) {
			Restauration rest = new Restauration("diner restaurant");
			setOption(rest);
		}
	}
	
	/**
	 * Ajoute des objets Spa à listOptions
	 * @param nbSpa
	 */
	public void ajouterSpa(int nbSpa) {
		for (int i = 0; i < nbSpa; i++) {
			Spa spa = new Spa();
			setOption(spa);
		}
	}
	
	public void ajouterAutreOption(String description) {
			Autres autre = new Autres();
	}
	
	/**
	 * 
	 * @return ArrayList<Integer> contenant les id des chambres non disponibles pendant la période demandée
	 * @throws SQLException
	 */
	public  List<Integer> getChambresNonDispo() throws SQLException {
	
	// ON DISTINGUE 3 CAS (voir schéma rapport)
		
		//initialisation d'une liste qui va servir à stocker les id des chambres occupées
		List<Integer> listChambresOccupees = new ArrayList<Integer>(); 
		
		
		//1ER CAS
		java.lang.String sql1 = "SELECT * FROM reservation_chambre where (datedebutsejour >= ? AND datedebutsejour <= ?)  AND (statut != 'non validée')";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql1);
		pstate.setDate(1, convertionUtilToSqlWH(convertionDate(this.dateDebutReserv))) ;
		pstate.setDate(2, convertionUtilToSqlWH(convertionDate(this.dateFinReserv))) ;
		
		ResultSet result = pstate.executeQuery(); 
		

			
		while (result.next()) {
			
			//la colonne id chambres simples reservees contient une string d'id
			String idSS1 = result.getString("idchambressimplesreservees"); 
			// on recupére la string
			
			if(idSS1.length() != 0) {
			//on récupére que les entiers de la string qu'on met dans une ??
			java.util.List<String> listeIdSS1 = Arrays.asList(idSS1.split(";"));
			
			for (int i = 0; i < listeIdSS1.size(); i++) {
				int idS1 = Integer.parseInt(listeIdSS1.get(i)); 
					
				listChambresOccupees.add(idS1);
				
			}}
			//on fait pareil pour les chambres doubles
			String idSD1 = result.getString("idchambresdoublesreservees");
			
			if(idSD1.length() != 0) {
			java.util.List<String> listeIdSD1 = Arrays.asList(idSD1.split(";"));
			
			for (int j = 0; j < listeIdSD1.size(); j++) {
				int idD1 = Integer.parseInt(listeIdSD1.get(j)); 
					
				listChambresOccupees.add(idD1);
				
			}}
			//pour les chambres composées
			String idSC1 = result.getString("idchambrescomposeesreservees");
			
			if(idSC1.length() != 0) {
			java.util.List<String> listeIdSC1 = Arrays.asList(idSC1.split(";"));
						
			for (int l = 0; l <listeIdSC1.size(); l++) {
				int idC1 = Integer.parseInt(listeIdSC1.get(l)); 
				listChambresOccupees.add(idC1);		}}	
		}
		
		// 2IEME CAS
		
		java.lang.String sql2 = "SELECT * FROM reservation_chambre where (datefinsejour >= ? AND datefinsejour <= ?) AND (statut != 'non validée' )";
		PreparedStatement pstate2 = Connexion.getInstance().prepareStatement(sql2);
		pstate2.setDate(1, convertionUtilToSqlWH(convertionDate(this.dateDebutReserv))) ;
		pstate2.setDate(2, convertionUtilToSqlWH(convertionDate(this.dateFinReserv))) ;
		ResultSet result2 = pstate2.executeQuery(); 
		
		while (result2.next()) {
			
			
			
			
			
			String idSS2 = result2.getString("idchambressimplesreservees");
			
			
			if (idSS2.length() != 0) {
			java.util.List<String> listeIdSS2 = Arrays.asList(idSS2.split(";"));
			
			for (int i = 0; i < listeIdSS2.size(); i++) {
				int idS2 = Integer.parseInt(listeIdSS2.get(i)); 
				listChambresOccupees.add(idS2);
				;
			}}
			
			String idSD2 = result2.getString("idchambresdoublesreservees");
		
		
			if (idSD2.length() != 0) {
			java.util.List<String> listeIdSD2 = Arrays.asList(idSD2.split(";"));
		
			
			for (int j2 = 0; j2 < listeIdSD2.size(); j2++) {
				int idD2 = Integer.parseInt(listeIdSD2.get(j2)); 
				listChambresOccupees.add(idD2);
			
			}}
			
			String idSC2 = result2.getString("idchambrescomposeesreservees");
			
			if (idSC2.length() != 0) {
			
			List<String> listeIdSC2 = Arrays.asList(idSC2.split(";"));
					
			for (int l = 0; l < listeIdSC2.size(); l++) {
				
				int idC2 = Integer.parseInt(listeIdSC2.get(l)); 
				listChambresOccupees.add(idC2);
				
						
			
			}}
				
		}
		
		// 3IEME CAS
		
		java.lang.String sql3 = "SELECT * FROM reservation_chambre where (datedebutsejour <= ? AND datefinsejour >= ?) AND (statut != 'non validée' )";
		PreparedStatement pstate3 = Connexion.getInstance().prepareStatement(sql3);
		pstate3.setDate(1, convertionUtilToSqlWH(convertionDate(this.dateDebutReserv))) ;
		pstate3.setDate(2, convertionUtilToSqlWH(convertionDate(this.dateFinReserv))) ;
		ResultSet result3 = pstate3.executeQuery(); 
		while (result3.next()) {
			
			
		
			String idSS3 = result3.getString("idchambressimplesreservees");
			
			if (idSS3.length() != 0) {
			java.util.List<String> listeIdSS3 = Arrays.asList(idSS3.split(";"));
			
			for (int i1 = 0; i1 < listeIdSS3.size(); i1++) {
				int id1 = Integer.parseInt(listeIdSS3.get(i1)); 
				listChambresOccupees.add(id1);
			}}
			
			String idSD3 = result3.getString("idchambresdoublesreservees");
			
			if (idSD3.length() != 0) {
			
			java.util.List<String> listeIdSD3 = Arrays.asList(idSD3.split(";"));
			
			for (int j3 = 0; j3 < listeIdSD3.size(); j3++) {
				int idD3 = Integer.parseInt(listeIdSD3.get(j3)); 
				listChambresOccupees.add(idD3);
			}}
			
			String idSC3 = result3.getString("idchambrescomposeesreservees");
			if (idSC3.length() != 0) {
			java.util.List<String> listeIdSC3 = Arrays.asList(idSC3.split(";"));
					
			for (int l = 0; l < listeIdSC3.size(); l++) {
				
				int idC3 = Integer.parseInt(listeIdSC3.get(l)); 
				listChambresOccupees.add(idC3);
				
			
			}}
		
		}
		return listChambresOccupees;	
	}
		/**
		 * Affecte des chambres à la reservation en fonction du nombre de chambres simples, doubles et composées demandées
		 * et des chambres disponibles à cette période
		 * @param list
		 * @throws SQLException
		 */ 
		public void affecterChambreToReservation(List<Integer> list) throws SQLException {
			
		//initialisation d'une liste qui va servir à stocker les id de toutes les chambres libres
		List<Integer> listChambresLibres = new ArrayList<Integer>(); 
		
		java.lang.String sql4 = "SELECT id FROM chambre_simple"; //on va recuperer tout les id des chambres simples
		
		
		PreparedStatement pstate4 = Connexion.getInstance().prepareStatement(sql4);
		ResultSet result4 = pstate4.executeQuery(); 
		
		while (result4.next()) {
			
		
			int idChambre = result4.getInt("id");
		
			
			if (list.contains(idChambre) )   {
				
			}
			else {
			
			listChambresLibres.add(idChambre);	
		}
		}	
		java.lang.String sql5 = "SELECT id FROM chambre_double";
		PreparedStatement pstate5 = Connexion.getInstance().prepareStatement(sql5);
		ResultSet result5 = pstate5.executeQuery();
		
		while (result5.next()) {
			
			
			int idChambreP = result5.getInt("id");
			
			if (list.contains(idChambreP) )   {
				
			}
			else {
			
			listChambresLibres.add(idChambreP);
		}}
			
		java.lang.String sql6 = "SELECT id FROM chambre_composee";
		PreparedStatement pstate6 = Connexion.getInstance().prepareStatement(sql6);
		ResultSet result6 = pstate6.executeQuery();
		
		while (result6.next()) {
			
			
			int idChambrePP = result6.getInt("id");
			
			if (list.contains(idChambrePP) )   {
				
			}
			else {
			
			listChambresLibres.add(idChambrePP);
			
		}
			
		}
		
		
		// à ce stade on a remplie la liste des id des chambres libres
		// separation de la liste en 3 listes
		
		ArrayList<Integer> listChambresSimplesLibres = new ArrayList<Integer>();
	    ArrayList<Integer> listChambresDoublesLibres = new ArrayList<Integer>();
		ArrayList<Integer> listChambresComposeesLibres = new ArrayList<Integer>();
		
		
		for (int i = 0; i < listChambresLibres.size(); i++) {
			
			
			if ( listChambresLibres.get(i) < 6 )// c'est une chambre simple   
				
				{ listChambresSimplesLibres.add(listChambresLibres.get(i)); }
			
			if (  listChambresLibres.get(i) < 11 && listChambresLibres.get(i) > 5) // c'est une chambre double  
			{ listChambresDoublesLibres.add(listChambresLibres.get(i)); }
			
			else  if (listChambresLibres.get(i) > 10 ){ listChambresComposeesLibres.add(listChambresLibres.get(i));
			}
		}
		
		
		//affectation des chambres à la reservation
		
		if (this.nbChambresSimples <= listChambresSimplesLibres.size()  &&  this.nbChambresDoubles <= listChambresDoublesLibres.size() 
				&& this.nbChambresComposees <= listChambresComposeesLibres.size() ) {
			validerDemande();
			System.out.println("la demande de reservation a été validée !");
		
		//initialisation de 3 listes qui vont stocker les id des chambres reservées
			
		ArrayList<Integer> listChambresSimplesReserveesId = new ArrayList<Integer>();
	    ArrayList<Integer> listChambresDoublesReserveesId = new ArrayList<Integer>();
		ArrayList<Integer> listChambresComposeesReserveesId = new ArrayList<Integer>();
		
		ArrayList<ChambreSimple> listChambresSimplesReservees = new ArrayList<ChambreSimple>();
		ArrayList<ChambreDouble> listChambresDoublesReservees = new ArrayList<ChambreDouble>();
		ArrayList<ChambreComposee> listChambresComposeesReservees = new ArrayList<ChambreComposee>();
		
		String listNomChambresSimplesReservees = "";
		
		for (int i = 0; i < this.nbChambresSimples; i++) {
			ChambreSimple chambre = new ChambreSimple(listChambresSimplesLibres.get(i));
			chambre.getInfoChambreBDD();
			String nomChambre = chambre.getNom(); //on récupére le nom de la chambre
			listChambresSimplesReserveesId.add(listChambresSimplesLibres.get(i));
			listChambresSimplesReservees.add(chambre);
			listNomChambresSimplesReservees += nomChambre + ";";
			
		}
		this.listChambresSimplesReservees = listChambresSimplesReservees;
		
		String listNomChambresDoublesReservees = "";
		
		for (int i = 0; i < this.nbChambresDoubles; i++) {
			ChambreDouble chambre = new ChambreDouble(listChambresDoublesLibres.get(i));
			chambre.getInfoChambreBDD();
			String nomChambre = chambre.getNom(); 
			listChambresDoublesReserveesId.add(listChambresDoublesLibres.get(i));
			listChambresDoublesReservees.add(chambre);
			listNomChambresDoublesReservees += nomChambre + ";";
		}
		
		this.listChambresDoublesReservees = listChambresDoublesReservees;
		
		String listNomChambresComposeesReservees = "";
		
		for (int i = 0; i <this.nbChambresComposees; i++) {
			
			ChambreComposee chambre = new ChambreComposee(listChambresComposeesLibres.get(i));
			chambre.getInfoChambreBDD();
			String nomChambre = chambre.getNom();
			listChambresComposeesReserveesId.add(listChambresComposeesLibres.get(i));
			listChambresComposeesReservees.add(chambre);
			listNomChambresComposeesReservees += nomChambre + ";";	
		}	
		
		this.listChambresComposeesReservees = listChambresComposeesReservees;
	
		System.out.println("Les chambres ont été attribuées à la reservation" 
				+ "/les chambres que les clients vont occupées sont la/les chambre(s) " +
				listNomChambresSimplesReservees + listNomChambresDoublesReservees + listNomChambresComposeesReservees);
		}
		
		else { System.out.println("la reservation n'a pas été validée");
		}
		
	}
	/**
	 * 
	 * @return une liste avec les noms de toutes les options de la réservations
	 */
	public String stringOptions()	{
		String string = "";
		if(this.listOptions.size() != 0) {
		for (int i = 0; i < this.listOptions.size(); i++) {
			IOption option = listOptions.get(i);
			string += ";" + option.getDescription();	
		}}
		
		return string;
	}
	
	/**
	 * Ajoute la réservation dans la base de données
	 * @param idClient
	 * @throws SQLException
	 */
	
	public void ajouterReservation(int idClient) throws SQLException {
		
	java.lang.String sql = "INSERT INTO reservation_chambre(datedebutsejour,datefinsejour,nbpersonnes,nbchambressimple,nbchambresdoubles,nbchambrescomposees,id,statut,idclient,listoptions) VALUES (?,?,?,?,?,?,?,?,?,?) ";
	PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
	pstate.setDate(1, convertionUtilToSqlWH(convertionDate(this.dateDebutReserv)));
	pstate.setDate(2, convertionUtilToSqlWH(convertionDate(this.dateFinReserv)));
	pstate.setInt(3, this.nbPersonnes);
	pstate.setInt(4,  this.nbChambresSimples);
	pstate.setInt(5, this.nbChambresDoubles);
	pstate.setInt(6, this.nbChambresComposees);
	pstate.setInt(7, this.id);
	pstate.setString(8, this.statut);
	pstate.setInt(9, idClient);
	pstate.setString(10, this.stringOptions());
	pstate.executeUpdate();
		
		
		//Construction d'une string des id des chambres simples réservées
		String listChambresSimplesReserveesIdString = "";
		if (listChambresSimplesReservees != null) {
		for (int k = 0; k < this.listChambresSimplesReservees.size(); k++) {
			
			
			ChambreSimple chambreS = listChambresSimplesReservees.get(k);
			int idS = chambreS.getId();
			
			
			
			listChambresSimplesReserveesIdString   += idS + ";";
			}
		
		java.lang.String sqlS = "UPDATE reservation_chambre SET  idchambressimplesreservees = ? where id = ?";
		PreparedStatement pstateS = Connexion.getInstance().prepareStatement(sqlS);
		pstateS.setString(1, listChambresSimplesReserveesIdString) ;
        pstateS.setInt(2, this.id) ;
		pstateS.executeUpdate();
		}
		
		//Construction d'une string des id des chambres doubles réservées
		String listChambresDoublesReserveesIdString = "";
		if (listChambresDoublesReservees != null) {
		for (int i = 0; i < this.listChambresDoublesReservees.size(); i++) {		
		ChambreDouble chambreD = listChambresDoublesReservees.get(i);
		int idD = chambreD.getId();
		listChambresDoublesReserveesIdString   += idD + ";";
		}
		
		java.lang.String sqlD = "UPDATE reservation_chambre SET  idchambresdoublesreservees = ? where id = ?";
		PreparedStatement pstateD = Connexion.getInstance().prepareStatement(sqlD);
		pstateD.setString(1, listChambresDoublesReserveesIdString) ;
		pstateD.setInt(2, this.id) ;
		pstateD.executeUpdate();
		}
		
		//Construction d'une string des id des chambres composées réservées
		String listChambresComposeesReserveesIdString = "";
		if (listChambresComposeesReservees != null) {	
		for (int j = 0; j < this.listChambresComposeesReservees.size(); j++) {	
		ChambreComposee chambreC = listChambresComposeesReservees.get(j);
		int idC = chambreC.getId();
		listChambresComposeesReserveesIdString   += idC + ";";	
		}
			
		java.lang.String sqlC= "UPDATE reservation_chambre SET  idchambrescomposeesreservees = ? where id = ?";
		PreparedStatement pstateC = Connexion.getInstance().prepareStatement(sqlC);
		pstateC.setString(1, listChambresComposeesReserveesIdString ) ;
		pstateC.setInt(2, this.id) ;
		pstateC.executeUpdate();
		
		//Ajoute l'id du client comme clé étrangére 	
		java.lang.String sqlE = "UPDATE reservation_chambre SET idClient = ? WHERE id = ?";
		PreparedStatement pstateE = Connexion.getInstance().prepareStatement(sqlE);
		pstateE.setInt(1, idClient); 
		pstateE.setInt(2, this.id);
		pstateE.executeUpdate();	
		}	
			
	}}
	
	
	