package General;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Connexion {

	//CONNEXION A LA BASE DE DONNEES
	private final String DB_URL = "jdbc:postgresql://localhost:5432/Hotel";
	private final String USER = "axel";

	private final String PASS = "axel";
	private static Connection connection; // l’objet Connection

	private Connexion() { // Constructeur prive ! Objet impossible a instancier
		try {
			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	// methode qui retourne l’instance et qui la cree si elle n’existe pas encore
	public static Connection getInstance(){
		if(connection == null){
			
			new Connexion();
		}
		return connection;
	}
}

