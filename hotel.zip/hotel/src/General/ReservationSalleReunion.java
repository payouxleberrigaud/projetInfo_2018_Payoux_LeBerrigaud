package General;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import SalleReunion.SalleReunion;

public class ReservationSalleReunion extends Reservation{
	
	SalleReunion salleReservee;
	private String heureDebutReserv; //de la forme "yyyy-MM-dd HH:mm:ss"
	private String heureFinReserv;
	String date;
	
	//CONSTRUCTEUR
	public ReservationSalleReunion(String type,String date,String heureDebutReserv ,String heureFinReserv, int nbPersonnes) throws SQLException {
		super(nbPersonnes, type);
		this.date = date;
		this.heureDebutReserv = heureDebutReserv;
		this.heureFinReserv = heureFinReserv;
	}
	
	//GETTERS
	public String getHD() {
		//sert pour calculer le prix 
		
		return   this.heureDebutReserv;
		
	}
	public String getHF() {
		//sert pour calculer le prix 
		
		return   this.heureFinReserv;
		
	}
	
	/**
	 * 
	 * @return une liste d'id des salles non disponibles pendant le créneau demandé
	 * @throws SQLException
	 */
	public ArrayList<Integer>  verifierSallesNonDispo() throws SQLException {
		
		
		ArrayList<Integer> idSallesOccupees = new ArrayList<Integer>();
		//ON DISTINGUE 3 CAS EN CE QUI CONCERNE LES CHEVAUCHEMENTS DE CRENEAU ENTRE RESERVATIONS
		//LE 4iEME CAS OU UNE SALLE EST CONSIDEREE NON DISPONIBLE C EST QUAND ELLE NE POSSEDE PAS ASSEZ DE SIEGES
		
		//1ER CAS
		
		java.lang.String sql1 = "SELECT * FROM reservation_sr where ( date = ? AND ? < heuredebutreserv  AND ? > heurefinreserv ) ";
		PreparedStatement pstate1 = Connexion.getInstance().prepareStatement(sql1);
		
		
		pstate1.setDate(1,convertionUtilToSqlWH(convertionDate(this.date)));
		pstate1.setTimestamp(2, Timestamp.valueOf(this.heureDebutReserv)) ;
		pstate1.setTimestamp(3,Timestamp.valueOf(this.heureFinReserv)) ;
		
		ResultSet result1 = pstate1.executeQuery(); 
		
		while (result1.next()) {
			
		int idSO = result1.getInt("idsallereservee"); //on récupére idsallereservee de la requête ( de la reservation qui tombe sur ce créneau)
			
		idSallesOccupees.add(idSO);	
		}
		
		//2IEME CAS
		java.lang.String sql2 = "SELECT * FROM reservation_sr where ( date = ? AND (heuredebutreserv <= ? AND heurefinreserv >= ?) ) ";
		PreparedStatement pstate2 = Connexion.getInstance().prepareStatement(sql2);
		
		pstate2.setDate(1,convertionUtilToSqlWH(convertionDate(this.date)));
		pstate2.setTimestamp(2, Timestamp.valueOf(this.heureDebutReserv)) ;
		pstate2.setTimestamp(3,Timestamp.valueOf(this.heureFinReserv)) ;
		
		ResultSet result2 = pstate2.executeQuery(); 
		while (result2.next()) {
			
		int idSO = result2.getInt("idsallereservee");
			
		idSallesOccupees.add(idSO);	
		
		}
		
		//3IEME CAS
		java.lang.String sql3 = "SELECT * FROM reservation_sr where ( (date = ? ) AND (heurefinreserv between ? and ?) ) ";
		PreparedStatement pstate3 = Connexion.getInstance().prepareStatement(sql3);
		
		pstate3.setDate(1,convertionUtilToSqlWH(convertionDate(this.date)));
		pstate3.setTimestamp(2, Timestamp.valueOf(this.heureDebutReserv)) ;
		pstate3.setTimestamp(3, Timestamp.valueOf(this.heureFinReserv)) ;
		
		
		ResultSet result3 = pstate3.executeQuery(); 
		while (result3.next()) {
			
		int idSO = result3.getInt("idsallereservee");
			
		idSallesOccupees.add(idSO);	
		}
		
		//4IEME CAS 
		
		java.lang.String sql4 = "SELECT * FROM salle_reunion where nbsiege < ? ";
		PreparedStatement pstate4 = Connexion.getInstance().prepareStatement(sql4);
		
		pstate4.setInt(1,this.nbPersonnes);
		
		
		ResultSet result4 = pstate4.executeQuery();
		
		while (result4.next()) {
			
			
		int idSO = result4.getInt("id");
		
			
		idSallesOccupees.add(idSO);	
		
		}
		
		return idSallesOccupees;
}
	
	    /**
	     * Affecte une salle à la réservation
	     * @param idSallesOccupees
	     * @throws SQLException
	     */
		public void affecterSalleToReser(ArrayList idSallesOccupees) throws SQLException {
		
		//on initialise une liste qui va contenir les id des salles libres
		List<Integer> listSallesLibres = new ArrayList<Integer>(); 
		
		
		java.lang.String sql5 = "SELECT id FROM salle_reunion";
		//on parcout les salles et on prend le premier id qui n'est pas dans la liste des 
		//salles déja occupées pour l'affecter à la reservation
		
		PreparedStatement pstate5 = Connexion.getInstance().prepareStatement(sql5);
		ResultSet result5 = pstate5.executeQuery(); 
		
		SalleReunion salleReservee = new SalleReunion(0); //initialisation d'une salle de réunion 
	
		
		while (result5.next() && salleReservee.getId() == 0)  {
			//on parcourt toutes les salles de reunion
		
			int idSalle = result5.getInt("id");
		
			
			if (idSallesOccupees.contains(idSalle) )  // Si l'id de la salle se trouve dans la liste des salles non disponibles on fait rien
				{
				
			}
			else {
			
			salleReservee.setId(idSalle);  //Sinon on donne à la salle de reunion qu'on a initialisé plus haut cet identifiant
			
			
		}}
		
		if (salleReservee.getId() == 0) { // si la salle reservée a toujours son identifiant valant 0
			// ca veut dire qu'on lui a pas trouvé de salle libre.
			
		System.out.println( "Désolée il n'y a pas de salle disponible sur le créneau demandé !")	;
		}
		
		else { validerDemande();      // si l'id de la salle est différent de 0 alors on a trouvé une salle pour la reservation
			this.salleReservee = salleReservee;// l'attribut salleReservee devient l'ojet salle crée
			this.salleReservee.getInfoSalleBDD(); //on remplie tout les attributs de l'objet salle
		
		System.out.println( "La salle que vous occuperez est la salle " + this.salleReservee.getNom())	;
		}
		
	
		}
	/**
	 * Ajoute de la réservation dans la base de données
	 * @param idClient
	 * @throws SQLException
	 */
	
	public void ajouterReservation(int idClient) throws SQLException {
	//ajoute une reservation de salle dans la BDD 
	// on lui donne l'id du client qui sera clé étrangère de la ligne
		
	java.lang.String sql = "INSERT INTO reservation_sr(date,nbpersonnes,heuredebutreserv,heurefinreserv,statut,id,idclient) VALUES (?,?,?,?,?,?,?) ";
	PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
	pstate.setDate(1, convertionUtilToSqlWH(convertionDate(this.date))); 
	
	pstate.setInt(2, this.nbPersonnes);
	pstate.setTimestamp(3,  Timestamp.valueOf(this.heureDebutReserv)); //Timestanp transforme une string en date (jour+heure)
	pstate.setTimestamp(4,  Timestamp.valueOf(this.heureFinReserv));
	pstate.setString(5, this.statut);
	pstate.setInt(6,this.id);
	pstate.setInt(7, idClient);
	
	pstate.executeUpdate();	
	
	if (this.salleReservee != null) { //Si on a trouvé une salle libre pour la reservation = Si la réservation est validée 
		
	java.lang.String sqlS = "UPDATE reservation_sr SET idsallereservee = ? where id = ? ";
	
	PreparedStatement pstateS = Connexion.getInstance().prepareStatement(sqlS);
	pstateS.setInt(1 , this.salleReservee.getId());
	pstateS.setInt(2 , this.id);
	pstateS.executeUpdate();
	}	
	else {	}
	}

	/**
	 * Calcul la durée d'une réservation 
	 * On fait appel à cette méthode pour le calcul de prix de la réservation
	 * @param heureDebut
	 * @param heureFin
	 * @return une durée en minutes
	 * @throws ParseException
	 */
            
	public static long getDureeReserv(String heureDebut,String heureFin) throws ParseException {
	// calcul le nombre de minute entre deux date(jour+heure)
		
	java.util.Date d1 = convertionStringToUtil(heureDebut); 
	java.util.Date d2 = convertionStringToUtil(heureFin);
	 
	Date d3 = new Date(Math.abs(d1.getTime() - d2.getTime()));
	
	return (d3.getTime()/1000/60/60) * 60  + d3.getTime()/1000/60%60 ;
	//resultat en minutes quand pas de secondes
	}
}
	
