package General;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import Client.Client;
import Client.CompteFidelite;

import java.sql.SQLException;

public class MainHotel {

	public static void main(String[] args) throws ParseException, SQLException {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Vous désirez visualiser l'état des réservations ou gérer les réservations ?");
		String tache = scanner.nextLine();
		
		Scanner scannerInt = new Scanner(System.in);

		if ("visualiser".equals(tache)) {
			
			System.out.println("A partir de quelle date ? (format:2018-04-03)");
			String dateDebut =scanner.nextLine();

			System.out.println("Juqu'à quelle date? (format:2018-04-03)");
			String dateFin = scanner.nextLine();

			String stringDates = Reservation.listeDesDates(dateDebut, dateFin);
			List<String> listeDates = Arrays.asList(stringDates.split(","));
			new Planning(dateDebut, dateFin, listeDates).setVisible(true);
		}

		else {

			
			System.out.println("Quel est le nom du client ? ");
			String nom_client = scanner.nextLine();

			
			System.out.println("Quel est le prenom du client ?");
			String prenom_client = scanner.nextLine();
			
			
			System.out.println("Quel est le tel du client ? (int)");
			int tel = scannerInt.nextInt();

			
			System.out.println("Quel est le mail du client ? ");
			String mail = scanner.nextLine();

			Client.testClient(nom_client, prenom_client, tel, mail); // regarde si le client est dans la BDD si il y est
																		// pas ca l'ajoute
			Client client = Client.rechercherClient(nom_client, prenom_client); // on recherche le client
			int idClient = client.getId(); // on extrait l'id du client

			CompteFidelite compte = CompteFidelite.rechercheCompteFidelite(idClient);
			// on recherche son compte fidelité

			
			System.out.println("le client veut annuler ou reserver? (ecrire annuler ou reserver)"); // rentrer annuler ou reserver
			String annuler_ou_reserver = scanner.nextLine();

			if ("annuler".equals(annuler_ou_reserver)) {

				
				System.out.println("Quelle est le type de la reservation que le client veut annuler? (ecrire chambre ou salle)"); 
				String type = scanner.nextLine();
				Reservation.supprimerReservation(idClient, type);

			}

			else {
				
				System.out.println("Pour combien de personnes? (int)"); // int
				int nb_personnes =scannerInt.nextInt();

				
				System.out.println("Quelle est le type de la reservation ? (ecrire chambre ou salle)"); 
				String type = scanner.nextLine();

				if ("chambre".equals(type)) {
					
					System.out.println("A partir de quelle date? (format 2018-04-03) "); // forme : 2018-04-03
					String dateDebutSejour = scanner.nextLine();

					
					System.out.println("Jusqu'à quelle date? (format 2018-04-03)"); // forme : 2018-04-03
					String dateFinSejour = scanner.nextLine();

					
					System.out.println("Combien de chambres simples? "); // int
					int nb_chambres_simples = scannerInt.nextInt();

					
					System.out.println("Combien de chambres doubles? "); // int
					int nb_chambres_doubles = scannerInt.nextInt();

					
					System.out.println("Combien de chambres composees? "); // int
					int nb_chambres_composees = scannerInt.nextInt();

					
					System.out.println("Le client veut-il des options? (ecrire oui ou non)"); // oui ou non
					String option = scanner.nextLine();

					int nbPetitDejChambre = 0;
					int nbPetitDejRestaurant = 0;
					int nbDejeunerChambre = 0;
					int nbDejeunerRestaurant = 0;
					int nbDinerChambre = 0;
					int nbDinerRestaurant = 0;
					int nbSpa = 0;

					if ("oui".equals(option)) {

						
						System.out.println("Combien de petit déjeuner dans la chambre? "); // int
						nbPetitDejChambre = scannerInt.nextInt();

						
						System.out.println("Combien de petit dejeuner au restaurant? "); // int
						nbPetitDejRestaurant = scannerInt.nextInt();

						
						System.out.println("Combien de dejeuner dans la chambre? "); // int
						nbDejeunerChambre = scannerInt.nextInt();

						
						System.out.println("Combien de dejeuner au restaurant? "); // int
						nbDejeunerRestaurant = scannerInt.nextInt();

						
						System.out.println("Combien de diner dans la chambre? "); // int
						nbDinerChambre = scannerInt.nextInt();

						
						System.out.println("Combien de diner au restaurant? "); // int
						nbDinerRestaurant = scannerInt.nextInt();

						
						System.out.println("Combien de séances de spa? "); // int
						nbSpa = scannerInt.nextInt();
					}

					int nbOption = nbPetitDejChambre + nbPetitDejRestaurant + nbDejeunerChambre + nbDejeunerRestaurant
							+ nbDinerChambre + nbDinerRestaurant + nbSpa;

					ReservationChambre reservation = new ReservationChambre(type, dateDebutSejour, dateFinSejour,
							nb_personnes, nb_chambres_simples, nb_chambres_doubles, nb_chambres_composees);
					if (nbOption > 0) {
						if (nbPetitDejChambre + nbPetitDejRestaurant > 0) {

							reservation.ajouterPetitDej(nbPetitDejChambre, nbPetitDejRestaurant);
						}
						if (nbDejeunerChambre + nbDejeunerRestaurant + nbDinerChambre + nbDinerRestaurant > 0) {
							reservation.ajouterRestauration(nbDejeunerChambre, nbDejeunerRestaurant, nbDinerChambre,
									nbDinerRestaurant);

						}
						if (nbSpa > 0) {
							reservation.ajouterSpa(nbSpa);

						}
					}

					reservation.affecterChambreToReservation(reservation.getChambresNonDispo());
					// reservation passe en validée si assez de chambres son libres et des chambres
					// sont affectées
					reservation.ajouterReservation(client.getId()); // on ajoute la reservation dans la BDD, si la
																	// reserv est restée en non validée elle est mise
					// quand meme dans la BDD mais sans chambres affectées

					if ("validée".equals(reservation.statut)) {
						int idReservation = reservation.getId(); // on extrait l'id de la réservation
						FactureReservChambre facture = new FactureReservChambre(idReservation); // l'id de la
																								// reservation est le
																								// meme que celui de la
																								// facture
						facture.ajouterFactureBDD(reservation, compte);

						facture.setPointFidelite(compte);
					}

					else {

					}
				}

				else if ("salle".equals(type)) {

					
					System.out.println("A quelle date ? "); // forme : 2018-04-03
					String date = scanner.nextLine();

					
					System.out.println("A partir de quelle heure ?"); // forme : 2018-07-02 12:00:00
					String heureDebut = scanner.nextLine();

				
					System.out.println("Jusqu'a quelle heure ?"); // forme : 2018-07-02 12:00:00
					String heureFin = scanner.nextLine();

					ReservationSalleReunion reservation = new ReservationSalleReunion(type, date, heureDebut, heureFin,
							nb_personnes);
					reservation.affecterSalleToReser(reservation.verifierSallesNonDispo());
					reservation.ajouterReservation(idClient);

					if ("validée".equals(reservation.statut)) {
						int idReservation = reservation.getId(); // on extrait l'id de la réservation
						FactureReservSalleReunion facture = new FactureReservSalleReunion(idReservation); 
						// l'id de la reservation est le meme que celui de la facture																					
						facture.ajouterFactureBDD(reservation, compte);
						facture.setPointFidelite(compte);

					}
				}
			}

		}
		scanner.close();
		scannerInt.close();
	}
	
}
