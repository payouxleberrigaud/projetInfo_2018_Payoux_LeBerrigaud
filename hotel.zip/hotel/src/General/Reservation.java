package General;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public abstract class Reservation {

	protected int id;
	private String type; // "chambre" ou "salle"
	protected int nbPersonnes;
	protected String statut = "non validée";

	// CONSTRUCTEUR
	
	public Reservation(int nbPersonnes, String type) throws SQLException {

		this.id = recupererIdReservation();
		this.nbPersonnes = nbPersonnes;
		this.type = type;

	}
	
	// GETTER

	public int getId() {
		return this.id;
	}
	
	// METHODES DE CONVERSION DES DATES ENTRE LES DIFFERENTS TYPES

	
	/**
	 * fonction appelée lors de la conversion d'une date String en date util
	 * 
	 */
	private static java.util.Date tryParse(String dateString, String formatString)
	
	{
		java.util.Date d = null;
		try {
			d = new SimpleDateFormat(formatString).parse(dateString);
		} catch (ParseException e) {
		}

		return d;
	}

	/**
	 * convertie une date String en date util fait appel à la fonction tryParse
	 */
	public static Date convertionDate(String date) {
		

		java.util.Date decisionDate = tryParse(date, "yyyy-MM-dd");
		return decisionDate;

	}
	
	/**
	 * convertie une date String en date Date util avec l'heure
	 * 
	 */
	public static Date convertionStringToUtil(String date) {
		

		java.util.Date decisionDate = tryParse(date, "yyyy-MM-dd HH:mm:ss");
		return decisionDate;

	}
	
	/**
	 * convertie une date Mon Jun 18 00:00:00 IST 2012 en date 2012-06-18
	 * 
	 */
	public static String recupererDate(String date) {
		
		String an;
		String jour = date.substring(8, 10);
		int jourInt = Integer.parseInt(jour);

		String mois = date.substring(4, 7);
		String moisNum = "";
		if ("Jan".equals(mois)) {
			moisNum = "01";
		}
		if ("Feb".equals(mois)) {
			moisNum = "02";
		}
		if ("Mar".equals(mois)) {
			moisNum = "03";
		}
		if ("Apr".equals(mois)) {
			moisNum = "04";
		}
		if ("May".equals(mois)) {
			moisNum = "05";
		}
		if ("Jun".equals(mois)) {
			moisNum = "06";
		}
		if ("Jul".equals(mois)) {
			moisNum = "07";
		}
		if ("Aug".equals(mois)) {
			moisNum = "08";
		}
		if ("Sep".equals(mois)) {
			moisNum = "09";
		}
		if ("Oct".equals(mois)) {
			moisNum = "10";
		}
		if ("Nov".equals(mois)) {
			moisNum = "11";
		}
		if ("Dec".equals(mois)) {
			moisNum = "12";
		}

		if (date.length() == 29) {
			an = date.substring(25, 29);
		} else { // exemple Mon Jun 18 00:00:00 IST 2012
			an = date.substring(24, 28);
		}
		String format = an + "-" + moisNum + "-" + jour;
		return format;

	}

	/**
	 * convertie une date Date util en date Date sql sans l'heure
	 * 
	 */
	public static java.sql.Date convertionUtilToSqlWH(java.util.Date date) {
		
		java.sql.Date d2 = new java.sql.Date(date.getTime());
		return d2;
	}
	
	
	/**
	 * Calcule l'id de la reservation en fonction du nombre de reservation de
	 * chambre et de salle déja dans la base de donnée Si il y en a déja n l'id de
	 * la reservation sera n+1
	 */
	public int recupererIdReservation() throws SQLException {
		java.lang.String sql = "SELECT COUNT (*) FROM reservation_chambre";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		ResultSet result = pstate.executeQuery();
		result.next();

		int reservChambre = result.getInt(1); // nombre de reservation de chambres

		java.lang.String sql_sr = "SELECT COUNT (*) FROM reservation_sr";
		PreparedStatement pstate_sr = Connexion.getInstance().prepareStatement(sql_sr);
		ResultSet result_sr = pstate_sr.executeQuery();
		result_sr.next();

		int reservSalle = result_sr.getInt(1); // nombre de reservation de salles

		int idNouvelleReservation = reservChambre + reservSalle + 1;
		return (idNouvelleReservation);
	}
	
	/**
	 * modifie le statut de la réservation
	 */
	public void validerDemande() {
		// modifie le statut de la réservation
		this.statut = "validée";
	}

	/**
	 * pour supprimer une réservation de la base de donnée, que ce soit une
	 * reservation chambre ou salle supprime en même temps la facture
	 */
	public static void supprimerReservation(int idClient, String type) throws SQLException {
		

		if ("chambre".equals(type)) {

			String sql_select_ch = " SELECT id FROM  reservation_chambre where idclient = ? "; //
			PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql_select_ch);
			pstate.setInt(1, idClient);
			ResultSet result = pstate.executeQuery();
			if (result.next()) {

				int id = result.getInt("id");

				String sql_delete_f = " DELETE FROM  facture where id = ? ";
				PreparedStatement pstate_f = Connexion.getInstance().prepareStatement(sql_delete_f);
				pstate_f.setInt(1, id);
				pstate_f.executeUpdate();
				System.out.println("la facture a bien été annulée");

				String sql_delete_ch = " DELETE FROM  reservation_chambre where idclient = ? ";
				PreparedStatement pstate1 = Connexion.getInstance().prepareStatement(sql_delete_ch);
				pstate1.setInt(1, idClient);
				pstate1.executeUpdate();
				System.out.println("la reservation a bien été annulée");
			} else {
				System.out.println("le client n'a pas de réservations à son nom");
			}
		}

		else {

			String sql_select_sr = " SELECT id FROM  reservation_sr where idclient = ? "; //
			PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql_select_sr);
			pstate.setInt(1, idClient);
			ResultSet result = pstate.executeQuery();
			if (result.next()) {
				int id = result.getInt("id");

				String sql_delete_f = " DELETE FROM  facture where id = ? ";
				PreparedStatement pstate_f = Connexion.getInstance().prepareStatement(sql_delete_f);
				pstate_f.setInt(1, id);
				pstate_f.executeUpdate();
				System.out.println("la facture a bien été supprimée !");

				String sql_delete = " DELETE FROM  reservation_sr where idclient = ?  ";
				PreparedStatement pstate_delete = Connexion.getInstance().prepareStatement(sql_delete);

				pstate_delete.setInt(1, idClient);
				pstate_delete.executeUpdate();
				System.out.println("la reservation a bien été supprimée!");
			} else {
				System.out.println("le client n'a pas de réservations à son nom");
			}
		}
	}

	/**
	 * affiche une liste de dates comprises entre 2 dates, date début et de fin
	 * incluses
	 * 
	 * @param les paramètres sont des String
	 */
	public static String listeDesDates(String dateDebutReserv, String dateFinReserv)
	
	{
		java.util.Date date1 = Reservation.convertionDate(dateDebutReserv);
		java.util.Date date2 = Reservation.convertionDate(dateFinReserv);

		GregorianCalendar gcd = new GregorianCalendar();
		gcd.setTime(date1);
		GregorianCalendar gcf = new GregorianCalendar();
		gcf.setTime(date2);
		String listeDates = "";

		while (gcd.before(gcf)) {
			listeDates = listeDates + gcd.getTime() + ",";
			gcd.add(GregorianCalendar.DATE, 1);

		}
		listeDates = listeDates + date2; // inclusion de la date de fin

		return listeDates;
	}

	/**
	 * affiche une liste de dates comprises entre 2 dates, date début et de fin
	 * incluses
	 * 
	 * @param les paramètres sont des java.util.Date
	 */
	public static String listeDesDates2(Date dateDebutReserv, Date dateFinReserv)
	

	{

		GregorianCalendar gcd = new GregorianCalendar();
		gcd.setTime(dateDebutReserv);
		GregorianCalendar gcf = new GregorianCalendar();
		gcf.setTime(dateFinReserv);
		String listeDates = "";

		while (gcd.before(gcf)) {
			listeDates = listeDates + gcd.getTime() + ",";
			gcd.add(GregorianCalendar.DATE, 1);

		}
		listeDates = listeDates + dateFinReserv;
		// supprimer le dernier caractère (;)

		return listeDates;
	}

	/**
	 * Affiche une requete qui joint les tables reservation_chambre et client
	 * 
	 */
	public static void afficherReservation() throws SQLException {
		

		String sql = "SELECT  FROM reservation_chambre INNER JOIN client ON reservation_chambre.idclient = client.id";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		ResultSet result = pstate.executeQuery();
		ResultSetMetaData resultMeta = result.getMetaData();

		for (int i = 1; i <= resultMeta.getColumnCount(); i++) {

			System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");
		}

		System.out.println("**********************************");
		while (result.next()) { // on va iterativement deplacer le curseur sur les differentes lignes de
			// resultats
			for (int i = 1; i <= resultMeta.getColumnCount(); i++) { // attention ! Les indices commencent a 1 ici
				if (result.getObject(i) != null) {
					System.out.print("\t" + result.getObject(i).toString() + "\t |");
				} else {
					System.out.print("\t" + "null" + "\t |");
				}
			}

			System.out.println("\n---------------------------------");
		}

		result.close();
	}

}
