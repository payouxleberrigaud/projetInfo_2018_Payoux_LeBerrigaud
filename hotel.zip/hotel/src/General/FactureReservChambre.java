package General;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import Chambre.ChambreComposee;
import Chambre.ChambreDouble;
import Chambre.ChambreSimple;
import Client.CompteFidelite;
import Options.IOption;

public class FactureReservChambre {
	private int id;
	private float total;
	private float prix;
	private int remise;
	private float prix_options = 0;
	public String debutHauteSaison = "2018-05-01";
	public String finHauteSaison = "2018-09-31";

	//CONSTRUCTEUR 
	
	public FactureReservChambre(int id) {
		this.id = id;
	}
	
	//SETTER
	public void setRemise(int remise) {
		this.remise = remise;
	}
	
	/**
	 * Calcul le prix de la reservation en fonction du nombre sa durée et de son appartenance ou non à la période de haute saison.
	 * @param reservation
	 * @return
	 */
	public float calculPrixReservation(ReservationChambre reservation) {
		// voir double, float
		double prix = 0;
		// creation de la liste des dates de haute saison
		String datesHauteSaisonString = reservation.listeDesDates(this.debutHauteSaison, this.finHauteSaison);
		List<String> listeDatesHauteSaison = Arrays.asList(datesHauteSaisonString.split(","));

		// creation de la liste des dates du séjour
		String listeDateString = reservation.listeDesDates(reservation.getDateDebut(), reservation.getDateFin());
		List<String> listeDate = Arrays.asList(listeDateString.split(","));

		for (int i = 0; i < listeDate.size(); i++) {

			double sommeAAjouter = reservation.getNbChambresSimples() * 100 + reservation.getNbChambresDoubles() * 150
					+ reservation.getNbChambresComposees() * 250;

			if (listeDatesHauteSaison.contains(listeDate.get(i))) {
				sommeAAjouter = sommeAAjouter * 1.20;
			}

			else {
				sommeAAjouter = sommeAAjouter;

			}

			prix = prix + sommeAAjouter;

		}

		BigDecimal number = new BigDecimal(prix);
		this.prix = number.floatValue();

		return this.prix;
	}
	
	
	/**
	 * Calcul la remise fidélité en fonction du nombre de points fidelité du client et enlève le nombre de points utilisé pour la remise au nombre
	 * de points du client
	 * @param compte
	 * @return
	 * @throws SQLException
	 */
	public int calculRemiseFidelite(CompteFidelite compte) throws SQLException {

		int nb_points = compte.getNbPoints();

		int remise = nb_points / 100;
		// division entiere car un entier divié
		// enelevr les points utlisés
		this.setRemise(remise);
		int nb_points_a_enlever = -remise * 100;
		compte.setNbPoints(nb_points_a_enlever);

		return this.remise;

	}

	/**
	 * Calcul le prix des options 
	 * @param reservation
	 * @return
	 */
	public float calculPrixOption(ReservationChambre reservation) {
		float prix = 0;
		IOption option;
		for (int i = 0; i < reservation.getOptions().size(); i++) {
			option = reservation.getOptions().get(i);
			prix += option.getPrix();
		}
		this.prix_options = prix;
		return prix;
	}

	/**
	 * Calcul le prix total
	 * @param reservation
	 * @param compte
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void calculPrixTotal(ReservationChambre reservation, CompteFidelite compte)
			throws SQLException, ParseException {

		// prix des options à rajouter

		this.total = calculPrixReservation(reservation) - calculRemiseFidelite(compte) - calculPrixOption(reservation);

	}

	/**
	 * Ajoute la facture dans la base de données
	 * @param reservation
	 * @param compte
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void ajouterFactureBDD(ReservationChambre reservation, CompteFidelite compte)
			throws SQLException, ParseException {
		calculPrixTotal(reservation, compte);
		System.out.println("Le client va payé" + this.total + "euros");
		// l'id de la facture est le meme que l'id de la reservation? voir quand on
		// creer la facture lui mettre le meme id
		java.lang.String sql = "INSERT INTO facture(id,prix,remise,total,idreserv,prix_options) VALUES (?,?,?,?,?,?) ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id);
		pstate.setFloat(2, this.prix);
		pstate.setInt(3, this.remise);
		pstate.setFloat(4, this.total);
		pstate.setInt(5, this.id);
		pstate.setFloat(6, this.prix_options);
		pstate.executeUpdate();

	}

	/**
	 * actualise le nombre de points fidélité en ajoutant ceux gagné après avoir payé la facture
	 * @param compte
	 * @throws SQLException
	 */
	public void setPointFidelite(CompteFidelite compte) throws SQLException {

		float total = this.total;
		int nb_points = (int) Math.floor(total / 10);

		compte.setNbPoints(nb_points);

	}
}
