package General;

import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JTable;


public class Planning extends JFrame {
	//CONSTRUCTEUR 
	public Planning(String dateDebut, String dateFin, List<String> listeDates) throws SQLException {
        super();
        String titre = "Planning des réservations du " + dateDebut + " au " + dateFin;
        	
    
    		int nb_dates = listeDates.size();
    		
        setTitle(titre);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000,1000); 
        setLocation(300,400);
        //Pour 4 dates ont obient le meilleure affichage
        
        
        //CONSTRUCTION DE L'ENTETE DU TABLEAU
        String[] entetes = creerEntete(listeDates);
        
        //CONSTRUCTION DES LIGNES
        String[] ligne1 = creerLigne(listeDates,"simple") ;
        String[] ligne2 = creerLigne(listeDates,"double") ;
        String[] ligne3 = creerLigne(listeDates,"composee") ;
       
     	Object[][] donnees = {
     			ligne1,ligne2,ligne3,
     			
                
        };
     	
     	JTable tableau = new JTable(donnees, entetes);
     	
     	//ajustement de la largueur des colonnes 
     	for (int i = 0; i < nb_dates; i++) {
        	tableau.getColumnModel().getColumn(i).setPreferredWidth(350);
     	}
     
     	tableau.setBackground(Color.ORANGE); 
        getContentPane().add(tableau.getTableHeader(), BorderLayout.NORTH);
        getContentPane().add(tableau, BorderLayout.CENTER);
 
        pack();
    } 
    
	 /**
     * méthode qui construit l'entete du tableau 
     * @param liste de dates List<String>, les String sont sous la forme Thu Feb 01 00:00:00 CET 2018
     **/
    public static String[] creerEntete(List<String> listeDates)   {
    	
    int nb_dates = listeDates.size();
    String[] entetes = new String [nb_dates];
    for (int i = 0; i < nb_dates; i++) {
    	entetes[i] = listeDates.get(i).toString();
    	
    }
    return entetes;
    }
    
    
    
	/**
	 * méthode qui construit une ligne du tableau 
	 **/
    public static String[] creerLigne(List<String> listeDates, String type_chambre) throws SQLException {
    	int nb_dates = listeDates.size();
    
    	String[] ligne = new String[nb_dates];
   
    for (int i = 0; i < nb_dates; i++) { //parcourir tout les jours entre les deux dates
    java.lang.String sql = "SELECT * FROM reservation_chambre where ? between datedebutsejour and datefinsejour"; //selectionner les reservations qui contiennent le jour
	PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
	
	
	pstate.setDate(1,Reservation.convertionUtilToSqlWH(Reservation.convertionDate(Reservation.recupererDate(listeDates.get(i)))));
	
	ResultSet result = pstate.executeQuery();
	
 	ArrayList<Integer> id_chambres_simples = new ArrayList<Integer>();
	ArrayList<Integer> id_chambres_doubles = new ArrayList<Integer>();
	ArrayList<Integer> id_chambres_composees = new ArrayList<Integer>();
	
	ligne [i] = "";
	
		while (result.next()) {
		//par reservation
			
		String string = result.getString("idchambressimplesreservees"); 
		System.out.println(string);
		if(string.length() != 0){ 	
			java.util.List<String> liste_id = Arrays.asList(string.split(";"));
			
			for (int i1 = 0; i1 < liste_id.size(); i1++) {
			//if(id_chambres_simples != null)
				if(id_chambres_simples.contains(Integer.parseInt(liste_id.get(i1))) ){}
				else { 
				id_chambres_simples.add(Integer.parseInt(liste_id.get(i1)));
				}}}
				
	
		String string2 = result.getString("idchambresdoublesreservees"); 
		if(string2.length() != 0){ 
			
			java.util.List<String> liste_id2 = Arrays.asList(string2.split(";"));
			
			for (int l = 0; l < liste_id2.size(); l++) {
				
				if(id_chambres_doubles.contains(Integer.parseInt(liste_id2.get(l))))
						{}
				else { id_chambres_doubles.add(Integer.parseInt(liste_id2.get(l)));}}}
		
	
		String string3= result.getString("idchambrescomposeesreservees"); 
		if(string3.length() != 0){ 
			java.util.List<String> liste_id = Arrays.asList(string3.split(";"));
			for (int k = 0; k < liste_id.size(); k++) {
		
				if(id_chambres_composees.contains(Integer.parseInt(liste_id.get(k))) ){}
				else { id_chambres_composees.add(Integer.parseInt(liste_id.get(k)));	}}}
		}
		
	if ("simple".equals(type_chambre)) {
		ligne[i] += "le nombre de chambres simples réservées est " + id_chambres_simples.size() 	;
	}
	if ("double".equals(type_chambre)) {
		ligne[i] += "le nombre de chambres doubles réservées est " + id_chambres_doubles.size() 	;
	}
	if ("composee".equals(type_chambre)) {
		ligne[i] += "le nombre de chambres composées réservées est " + id_chambres_doubles.size() 	;
	}
    }
	return ligne;	
	}
	
   
}   
    	
    	
   
   
 
   