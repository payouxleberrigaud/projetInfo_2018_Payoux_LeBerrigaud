package General;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Client.Client;
import Client.CompteFidelite;

public class InterfaceGraphique {

	/**
	 * Class Fenetre Permet d'afficher l'interface de l'hotel Contient un
	 * constructeur Fenetre() pour afficher la premiere fenetre
	 * 
	 */

	public static class Fenetre extends JFrame {

		// Attributs
		// JTextField pour pouvoir rentrer du texte dans un bouton
		// JLabel = Panneau (espace pour inserer des elements dans la page)
		private JTextField jtf = new JTextField();
		private JLabel label = new JLabel("Nom du client");

		private JTextField jtf1 = new JTextField();
		private JLabel label1 = new JLabel("Prénom du client");

		private JTextField nb = new JTextField();
		private JLabel nombre = new JLabel("Nombre de personne");

		private JTextField dated = new JTextField();
		private JLabel dated1 = new JLabel("Date du début de séjour (YYYY-MM-DD)");

		private JTextField datef = new JTextField();
		private JLabel datef1 = new JLabel("Date de fin de séjour (YYYY-MM-DD)");

		private JTextField datedp = new JTextField();
		private JLabel datedp1 = new JLabel("A partir de quelle date ? (YYYY-MM-DD)");

		private JTextField datefp = new JTextField();
		private JLabel datefp1 = new JLabel("Jusqu'a quelle date ? (YYYY-MM-DD)");

		private JComboBox combo = new JComboBox();
		private JLabel CS = new JLabel("Chambre simple");

		private JComboBox combo1 = new JComboBox();
		private JLabel CD = new JLabel("Chambre double");

		private JComboBox combo2 = new JComboBox();
		private JLabel CC = new JLabel("Chambre compose");

		private JLabel annuler = new JLabel("la reservation est annule");
		private JLabel finale = new JLabel("La réservation est validée");
		private JLabel finale2 = new JLabel("La réservation n'est pas validée");
		private JLabel planning = new JLabel("Le planning");

		private JTextField date = new JTextField();
		private JLabel date1 = new JLabel("Date (YYYY-MM-DD)");

		private JTextField heureds = new JTextField();
		private JLabel heured = new JLabel("A partir de quelle heure ? (YYYY-MM-DD 00:00:00)");

		private JTextField heurefs = new JTextField();
		private JLabel heuref = new JLabel("Jusqu' quelle heure ? (YYYY-MM-DD 00:00:00) ");

		private JComboBox comboannule = new JComboBox();
		private JTextField nbpetitdejch = new JTextField();
		private JLabel nbpetitdej1ch = new JLabel("Nombre de petit dejeuner dans la chambre");
		private JTextField nbpetitdejre = new JTextField();
		private JLabel nbpetitdej1re = new JLabel("Nombre de petit dejeuner au restaurant");
		private JTextField nbdejch = new JTextField();
		private JLabel nbdej1ch = new JLabel("Nombre de dejeuner dans la chambre");
		private JTextField nbdejre = new JTextField();
		private JLabel nbdej1re = new JLabel("Nombre de dejeuner au restaurant");
		private JTextField nbdiner = new JTextField();
		private JLabel nbdiner1 = new JLabel("Nombre de diner au restaurant");
		private JTextField nbdinerch = new JTextField();
		private JLabel nbdiner1ch = new JLabel("Nombre de diner dans la chambre");
		private JTextField spa = new JTextField();
		private JLabel spa1 = new JLabel("Nombre de sance de spa de 30 min");
		private JTextField autres = new JTextField();
		private JLabel autre = new JLabel("Autre");
		JTextField telephone = new JTextField();
		JLabel telephone1 = new JLabel("Telephone");
		JTextField mail = new JTextField();
		JLabel mail1 = new JLabel("AdresseMail");

		/**
		 * Constructeur Fenetre() Affiche la premiere fenetre avec 2 boutons Chaques
		 * boutons renvoi à une classe spécifique
		 */
		public Fenetre() {

			JFrame f = new JFrame();// Creer une fenetre
			JPanel b = new JPanel();// JLabel b : espace pour les boutons
			f.setTitle("Visualiser/Gerer"); // Titre de la fenetre
			f.setSize(800, 500); // Taille
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ferme la page quand on appui sur la croix en haut à
																// droite
			f.setLocationRelativeTo(null);
			b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS)); // Positionnement du panneau b

			JButton visu = new JButton("visualiser l'etat des reservations"); // Premier bouton
			b.add(visu); // Ajout du bouton au panneau b
			VisuListener visualiser = new VisuListener();
			visu.addActionListener(visualiser); // Lorsque l'on clic sur le bouton visu on actionne la classe
												// VisuListener()

			JButton gerer = new JButton("Gerer les reservations"); // Deuxieme bouton
			b.add(gerer);
			gerer.addActionListener(new GererListener()); // Lorsque l'on clic sur le bouton gerer on actionne la classe
															// GererListener()
			f.getContentPane().add(b); // Ajout du anneau b dans la fenetre
			f.setVisible(true); // Affiche la fenetre

		}

		/**
		 * Class GererListener() S'execute lorsque l'on appui sur le bouton " Gérer les
		 * réservations"
		 * 
		 */
		class GererListener implements ActionListener {
			// Affiche une fenetre où l'on peut rentrer le nom, le prenom, le téléphone et
			// le mail du client
			// Affiche un bouton valider
			public void actionPerformed(ActionEvent e) {
				// Caracteristique de la fenetre
				JPanel container = new JPanel();
				JFrame f = new JFrame();
				f.setTitle("Planning");
				f.setSize(800, 500);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.setLocationRelativeTo(null);
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				// Panneau où l'on rentre le nom et prenom
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);
				jtf.setFont(police);
				jtf.setPreferredSize(new Dimension(150, 30));
				jtf.setForeground(Color.BLUE);
				top.add(label);// Ajout du texte "nom du client"
				top.add(jtf);// Ajout de la case pour rentrer le nom du client
				container.add(top, BorderLayout.NORTH);
				f.setContentPane(container);

				jtf1.setFont(police);
				jtf1.setPreferredSize(new Dimension(150, 30));
				jtf1.setForeground(Color.BLUE);
				top.add(label1);// Ajout du texte "prenom du client"
				top.add(jtf1); // Ajout de la case pour rentrer le prenom du client
				container.add(top, BorderLayout.NORTH);

				// Panneau où l'on rentre le telephone
				JPanel b1 = new JPanel();
				telephone.setPreferredSize(new Dimension(30, 100));
				b1.setLayout(new BoxLayout(b1, BoxLayout.LINE_AXIS));
				b1.add(telephone1);
				b1.add(telephone);

				// Panneau où l'on rentre le mail
				JPanel b2 = new JPanel();
				mail.setPreferredSize(new Dimension(0, 0));
				b2.setLayout(new BoxLayout(b2, BoxLayout.LINE_AXIS));
				b2.add(mail1);
				b2.add(mail);

				// Panneau pour rassembler horizontalement b1 et b2
				JPanel b3 = new JPanel();
				// On positionne maintenant ces 2 lignes en colonne
				b3.setLayout(new BoxLayout(b3, BoxLayout.PAGE_AXIS));
				b3.add(b1);
				b3.add(b2);

				// Panneau pour le bouton valider
				JPanel b = new JPanel();
				JPanel south = new JPanel();
				b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS));

				f.getContentPane().add(b);
				JButton valider = new JButton("valider");
				south.add(valider);

				container.add(south, BorderLayout.SOUTH);
				container.add(b3);
				f.setVisible(true);

				valider.addActionListener(new ChoixListener());// Lorsque l'on clic sur le bouton valider on actionne la
																// classe choixListener()
			}
		}

		/**
		 * Class VisuListener() S'execute lorsque l'on appui sur le bouton "Visualiser
		 * les réservations"
		 *
		 */
		class VisuListener implements ActionListener {
			// Affiche une fenetre pour avoir le planning entre deux dates souhaitées
			// On peut rentrer la date de debut et la date de fin
			// Bouton valider

			public void actionPerformed(ActionEvent e) {
				// Caracteristique de la fenetre
				JFrame visu = new JFrame();
				visu.setTitle("Planning");
				visu.setSize(800, 500);
				visu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				visu.setLocationRelativeTo(null);
				JPanel container = new JPanel();
				JPanel valide = new JPanel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());

				// Panneau pour la date de depart
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);
				datedp.setFont(police);
				datedp.setPreferredSize(new Dimension(150, 30));
				datedp.setForeground(Color.BLUE);
				top.add(datedp1);
				top.add(datedp);
				container.add(top, BorderLayout.NORTH);

				// Panneau pour la date d'arrivée
				datefp.setFont(police);
				datefp.setPreferredSize(new Dimension(150, 30));
				datefp.setForeground(Color.BLUE);
				top.add(datefp1);
				top.add(datefp);
				container.add(top, BorderLayout.NORTH);

				// Bouton valider
				JButton valider = new JButton("valider");
				valide.add(valider);
				container.add(valide, BorderLayout.SOUTH);
				visu.getContentPane().add(container);
				finaleplanningListener finalplanning = new finaleplanningListener();
				valider.addActionListener(finalplanning);// Lorsque l'on clic sur le bouton valider on actionne la
															// classe finalplanningListener()

				visu.setVisible(true);
			}
		}

		/**
		 * Class ChoixListener() S'execute lorsque l'on appui sur le bouton "valider"
		 * sur les informations client
		 *
		 */
		class ChoixListener implements ActionListener {
			// Affiche une fenetre avec le bouton annuler et reserver

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String nom_client = jtf.getText(); // Recupere le nom du client
				String prenom_client = jtf1.getText(); // Recupere le prenom du client
				int tel = Integer.parseInt(telephone.getText()); // Recupere le telephone du client
				String adresseMail = mail.getText(); // Recupere le mail du client
				try {
					Client.testClient(nom_client, prenom_client, tel, adresseMail); // ajoute le client si il est pas
																					// dans la base de données
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} // regarde si le client est dans la BDD si il y est pas ca l'ajoute
				Client client = new Client();
				try {
					client = Client.rechercherClient(nom_client, prenom_client);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// Caracteristique de la fenetre

				JPanel container = new JPanel();
				JFrame f2 = new JFrame();
				f2.setSize(800, 500);
				f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f2.setLocationRelativeTo(null);
				JPanel b = new JPanel();
				JPanel cent = new JPanel();
				b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS));
				// Bouton reserver
				JButton reserver = new JButton("reserver");

				reserver.addActionListener(new ReserverListener(client));// Lorsque l'on clic sur le bouton reserver on
																			// actionne la classe ReserverListener()
				// Bouton annuler
				JButton annuler = new JButton("annuler");
				b.add(annuler);
				b.add(reserver);

				annuler.addActionListener(new AnnulerListener(client));// Lorsque l'on clic sur le bouton annuler on
																		// actionne la classe AnnulerListener()
				// f2.getContentPane().add(b);
				// Menu deroulant pour annuler soit une salle soit une chambre
				comboannule.setPreferredSize(new Dimension(100, 20));
				// Ajout des Item dans le menu deroulant

				comboannule.addItem("salle");
				comboannule.addItem("chambre");
				cent.add(comboannule);
				container.add(cent, BorderLayout.NORTH);

				f2.setContentPane(container);
				f2.getContentPane().add(b);

				f2.setVisible(true);
			}
		}

		/**
		 * Classe ReserverListener() S'execute lorsque l'on appui sur le bouton
		 * "reserver"
		 *
		 */
		class ReserverListener implements ActionListener {
			// Affiche une fenetre avec 2 boutons suivant si on veut reserver une chambre ou
			// une salle
			Client client;

			public ReserverListener(Client client) {
				this.client = client;
			}

			public void actionPerformed(ActionEvent e) {
				// Caracteristique de la fenetre
				JFrame f1 = new JFrame();
				f1.setTitle("Reserver/Annuler");
				f1.setSize(800, 500);
				f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f1.setLocationRelativeTo(null);
				// Panneau pour les boutons
				JPanel b = new JPanel();
				b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS));

				JButton salle = new JButton("salle_de_reunion");
				b.add(salle);
				JButton chambre = new JButton("chambre");
				b.add(chambre);
				chambre.addActionListener(new ChambreListener(this.client));// Lorsque l'on clic sur le bouton chambre
																			// on actionne la classe ChambreListener()
				salle.addActionListener(new SalleListener(this.client));// Lorsque l'on clic sur le bouton salle de
																		// reunion on actionne la classe SalleListener()

				JPanel container1 = new JPanel();
				JPanel top1 = new JPanel();
				container1.setBackground(Color.white);
				container1.setLayout(new BorderLayout());

				Font police = new Font("Arial", Font.BOLD, 14);
				nb.setFont(police);
				nb.setPreferredSize(new Dimension(150, 30));
				nb.setForeground(Color.BLUE);
				top1.add(nombre);
				top1.add(nb);
				container1.add(top1, BorderLayout.NORTH);
				f1.setContentPane(container1);
				f1.getContentPane().add(b);
				f1.setVisible(true);
			}
		}

		/**
		 * Class AnnulerListener() S'execute lorsque l'on appui sur le bouton "annuler"
		 *
		 */
		class AnnulerListener implements ActionListener {
			Client client;

			public AnnulerListener(Client client) {
				this.client = client;

			}

			public void actionPerformed(ActionEvent e) {
				// Caracteristique de la fenetre
				JFrame annule = new JFrame();
				annule.setTitle("Annuler");
				annule.setSize(800, 500);
				annule.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				annule.setLocationRelativeTo(null);

				JLabel container = new JLabel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);
				annuler.setFont(police);
				annuler.setPreferredSize(new Dimension(300, 30));
				annuler.setForeground(Color.BLUE);
				top.add(annuler);
				container.add(top, BorderLayout.NORTH);
				annule.setContentPane(container);

				// Annule la reservation suivant s'il clic sur salle ou chambre dans le menu
				// deroulant
				try {
					Reservation.supprimerReservation(this.client.getId(), (String) comboannule.getSelectedItem());

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				annule.setVisible(true);
			}
		}

		/**
		 * Class ChambreListener() S'execute lorsque l'on appui sur le bouton "chambre"
		 *
		 */
		class ChambreListener implements ActionListener {
			Client client;

			public ChambreListener(Client client) {
				this.client = client;
			}

			public void actionPerformed(ActionEvent e) {
				// Recupere l'Id du client
				int idClient = this.client.getId();
				// Caracteristique de la fenetre
				JFrame chambre = new JFrame();
				chambre.setTitle("Chambre");
				chambre.setSize(1000, 500);
				chambre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				chambre.setLocationRelativeTo(null);

				// C = nb.getText(); //C est le nombre de personne
				// System.out.println(C);

				// Panneau top pour rentrer les dates de de but et fin de reservation
				// Panneau cent pour les menus deroulants
				// Panneau south pour valider
				JPanel container = new JPanel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				JPanel cent = new JPanel();
				JPanel south = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);
				dated.setFont(police);
				dated.setPreferredSize(new Dimension(150, 30));
				dated.setForeground(Color.BLUE);
				top.add(dated1);
				top.add(dated);
				container.add(top, BorderLayout.NORTH);

				datef.setFont(police);
				datef.setPreferredSize(new Dimension(150, 30));
				datef.setForeground(Color.BLUE);
				top.add(datef1);
				top.add(datef);
				container.add(top, BorderLayout.NORTH);

				combo.setPreferredSize(new Dimension(100, 20));
				combo.addItem("0");
				combo.addItem("1");
				combo.addItem("2");
				combo.addItem("3");
				combo.addItem("4");
				combo.addItem("5");

				combo.setPreferredSize(new Dimension(100, 20));
				combo1.addItem("0");
				combo1.addItem("1");
				combo1.addItem("2");
				combo1.addItem("3");
				combo1.addItem("4");
				combo1.addItem("5");

				combo2.setPreferredSize(new Dimension(100, 20));
				combo2.addItem("0");
				combo2.addItem("1");
				combo2.addItem("2");
				combo2.addItem("3");

				cent.add(combo);
				cent.add(CS);
				cent.add(combo1);
				cent.add(CD);
				cent.add(combo2);
				cent.add(CC);

				nbpetitdejch.setFont(police);
				nbpetitdejch.setPreferredSize(new Dimension(150, 30));
				nbpetitdejch.setForeground(Color.BLUE);
				cent.add(nbpetitdej1ch);
				cent.add(nbpetitdejch);

				nbpetitdejre.setFont(police);
				nbpetitdejre.setPreferredSize(new Dimension(150, 30));
				nbpetitdejre.setForeground(Color.BLUE);
				cent.add(nbpetitdej1re);
				cent.add(nbpetitdejre);

				nbdejch.setFont(police);
				nbdejch.setPreferredSize(new Dimension(150, 30));
				nbdejch.setForeground(Color.BLUE);
				cent.add(nbdej1ch);
				cent.add(nbdejch);

				nbdejre.setFont(police);
				nbdejre.setPreferredSize(new Dimension(150, 30));
				nbdejre.setForeground(Color.BLUE);
				cent.add(nbdej1re);
				cent.add(nbdejre);

				nbdiner.setFont(police);
				nbdiner.setPreferredSize(new Dimension(150, 30));
				nbdiner.setForeground(Color.BLUE);
				cent.add(nbdiner1);
				cent.add(nbdiner);
				nbdinerch.setPreferredSize(new Dimension(150, 30));
				nbdinerch.setFont(police);
				nbdinerch.setForeground(Color.BLUE);
				cent.add(nbdiner1ch);
				cent.add(nbdinerch);

				spa.setFont(police);
				spa.setPreferredSize(new Dimension(150, 30));
				spa.setForeground(Color.BLUE);
				cent.add(spa1);
				cent.add(spa);

				autres.setFont(police);
				autres.setPreferredSize(new Dimension(150, 30));
				autres.setForeground(Color.BLUE);
				cent.add(autre);
				cent.add(autres);
				JButton valider = new JButton("valider");
				south.add(valider);
				container.add(cent, BorderLayout.CENTER);
				container.add(south, BorderLayout.SOUTH);
				chambre.setContentPane(container);
				finaleListener finale = new finaleListener(this.client);
				valider.addActionListener(new finaleListener(this.client));
				// System.out.println("ActionListener : action sur " + combo.getSelectedItem());

				chambre.setVisible(true);

			}
		}

		/**
		 * Class SalleListener S'execute lorsque l'on appui sur le bouton "salle"
		 *
		 */
		class SalleListener implements ActionListener {
			Client client;

			public SalleListener(Client client) {
				this.client = client;
			}

			String C;

			public void actionPerformed(ActionEvent e) {
				JFrame salle = new JFrame();

				salle.setTitle("Salle");
				salle.setSize(800, 500);
				salle.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				salle.setLocationRelativeTo(null);

				C = nb.getText(); // C est le nombre de personne
				System.out.println(C);

				JLabel container = new JLabel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				JPanel center = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 12);
				date.setFont(police);
				date.setPreferredSize(new Dimension(150, 30));
				top.add(date);
				top.add(date1);
				container.add(top, BorderLayout.NORTH);

				JPanel b1 = new JPanel();
				// On dfinit le layout en lui indiquant qu'il travaillera en ligne

				heureds.setPreferredSize(new Dimension(100, 30));
				b1.setLayout(new BoxLayout(b1, BoxLayout.LINE_AXIS));
				b1.add(heured);
				b1.add(heureds);

				JPanel b2 = new JPanel();
				// On dfinit le layout en lui indiquant qu'il travaillera en ligne

				heurefs.setPreferredSize(new Dimension(100, 30));
				b2.setLayout(new BoxLayout(b2, BoxLayout.LINE_AXIS));
				b2.add(heuref);
				b2.add(heurefs);

				JPanel b4 = new JPanel();
				// On positionne maintenant ces trois lignes en colonne
				b4.setLayout(new BoxLayout(b4, BoxLayout.PAGE_AXIS));
				b4.add(b1);
				b4.add(b2);

				JPanel south = new JPanel();
				JButton valider = new JButton("valider");
				south.add(valider);
				container.add(south, BorderLayout.SOUTH);

				valider.addActionListener(new finalesalleListener(this.client));
				container.add(b4);
				salle.setContentPane(container);

				salle.setVisible(true);
			}
		}

		/**
		 * Class finale Listener S'execute lorsque l'on appui sur le bouton "valider"
		 * quand on a rentrer toute les demandes du client pour la reservation de
		 * chambre
		 */
		class finaleListener implements ActionListener {
			Client client;

			public finaleListener(Client client) {
				this.client = client;
			}

			public void actionPerformed(ActionEvent e) {
				System.out.println(this.client);

				JFrame fin = new JFrame();

				fin.setTitle("Fin");
				fin.setSize(800, 500);
				fin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fin.setLocationRelativeTo(null);

				JLabel container = new JLabel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);

				container.add(top, BorderLayout.NORTH);

				String dateDebutSejour = dated.getText();
				String dateFinSejour = datef.getText();
				int nb_chambres_simples = Integer.parseInt((String) combo.getSelectedItem());
				int nb_chambres_doubles = Integer.parseInt((String) combo1.getSelectedItem());
				int nb_chambres_composees = Integer.parseInt((String) combo2.getSelectedItem());
				int nb_personnes = Integer.parseInt(nb.getText());
				String autreOption = autres.getText();

				int nbPetitDejChambre = Integer.parseInt(nbpetitdejch.getText());
				int nbPetitDejRestaurant = Integer.parseInt(nbpetitdejre.getText());
				int nbDejeunerChambre = Integer.parseInt(nbdejch.getText());
				int nbDejeunerRestaurant = Integer.parseInt(nbdejre.getText());
				int nbDinerRestaurant = Integer.parseInt(nbdiner.getText());
				int nbDinerChambre = Integer.parseInt(nbdinerch.getText());
				int nbSpa = Integer.parseInt(spa.getText());

				int nbOption = nbPetitDejChambre + nbPetitDejRestaurant + nbDejeunerChambre + nbDejeunerRestaurant
						+ nbDinerChambre + nbDinerRestaurant + nbSpa;

				fin.setVisible(true);
				ReservationChambre reservation;
				try {
					reservation = new ReservationChambre("chambre", dateDebutSejour, dateFinSejour, nb_personnes,
							nb_chambres_simples, nb_chambres_doubles, nb_chambres_composees);
					if (nbOption > 0) {
						if (nbPetitDejChambre + nbPetitDejRestaurant > 0) {

							reservation.ajouterPetitDej(nbPetitDejChambre, nbPetitDejRestaurant);
						}
						if (nbDejeunerChambre + nbDejeunerRestaurant + nbDinerChambre + nbDinerRestaurant > 0) {
							reservation.ajouterRestauration(nbDejeunerChambre, nbDejeunerRestaurant, nbDinerChambre,
									nbDinerRestaurant);

						}
						if (nbSpa > 0) {
							reservation.ajouterSpa(nbSpa);

						}

					}

					reservation.affecterChambreToReservation(reservation.getChambresNonDispo());

					reservation.ajouterReservation(client.getId());

					String statut = reservation.statut;

					if ("non validée".equals(statut)) {
						finale2.setFont(police);
						finale2.setPreferredSize(new Dimension(300, 30));
						finale2.setForeground(Color.BLUE);
						top.add(finale2);

					} else {

						int idReservation = reservation.getId(); // on extrait l'id de la réservation
						FactureReservChambre facture = new FactureReservChambre(idReservation); // l'id de la
																								// reservation est le
																								// meme que celui de la
																								// facture
						CompteFidelite compte = CompteFidelite.rechercheCompteFidelite(client.getId());
						facture.ajouterFactureBDD(reservation, compte);
						facture.setPointFidelite(compte);

						finale.setFont(police);
						finale.setPreferredSize(new Dimension(300, 30));
						finale.setForeground(Color.BLUE);
						top.add(finale);
						fin.setContentPane(container);

					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		}

		/**
		 * Class finaleSalleListener S'execute lorsque l'on appui sur le bouton
		 * "valider" quand on a rentrer toute les demandes du client pour la reservation
		 * de salle de reunion
		 */
		class finalesalleListener implements ActionListener {
			Client client;

			public finalesalleListener(Client client) {
				this.client = client;
			}

			public void actionPerformed(ActionEvent e) {
				JFrame fin = new JFrame();

				fin.setTitle("Fin");
				fin.setSize(800, 500);
				fin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fin.setLocationRelativeTo(null);

				JLabel container = new JLabel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);

				container.add(top, BorderLayout.NORTH);
				fin.setContentPane(container);

				String dateR = date.getText();
				String heureDebut = heureds.getText();
				System.out.println(heureDebut);
				String heureFin = heurefs.getText();
				int nb_personnes = Integer.parseInt(nb.getText());

				fin.setVisible(true);

				ReservationSalleReunion reservation = null;
				try {
					reservation = new ReservationSalleReunion("salle", dateR, heureDebut, heureFin, nb_personnes);
					reservation.affecterSalleToReser(reservation.verifierSallesNonDispo());
					reservation.ajouterReservation(this.client.getId());
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

				if ("validée".equals(reservation.statut)) {
					finale.setFont(police);
					finale.setPreferredSize(new Dimension(300, 30));
					finale.setForeground(Color.BLUE);
					top.add(finale);
					int idReservation = reservation.getId(); // on extrait l'id de la réservation
					FactureReservSalleReunion facture = new FactureReservSalleReunion(idReservation); // l'id de la
																										// reservation
																										// est le meme
																										// que celui de
																										// la facture
					CompteFidelite compte;
					try {
						compte = CompteFidelite.rechercheCompteFidelite(client.getId());
						facture.ajouterFactureBDD(reservation, compte);

						facture.setPointFidelite(compte);
					} catch (SQLException | ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					finale2.setFont(police);
					finale2.setPreferredSize(new Dimension(300, 30));
					finale2.setForeground(Color.BLUE);
					top.add(finale2);
				}

			}
		}

		/**
		 * Class finaleplanning() S'execute lorsque l'on appui sur le bouton "valider"
		 * quand on a rentrer les dates souhaité pour visualiser le planning
		 *
		 */
		class finaleplanningListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				JFrame fin = new JFrame();

				fin.setTitle("Fin");
				fin.setSize(800, 500);
				fin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fin.setLocationRelativeTo(null);

				JLabel container = new JLabel();
				container.setBackground(Color.white);
				container.setLayout(new BorderLayout());
				JPanel top = new JPanel();
				Font police = new Font("Arial", Font.BOLD, 14);
				planning.setFont(police);
				planning.setPreferredSize(new Dimension(300, 30));
				planning.setForeground(Color.BLUE);
				top.add(planning);
				container.add(top, BorderLayout.NORTH);
				fin.setContentPane(container);

				String dateDebut = datedp.getText();
				String dateFin = datefp.getText();

				String stringDates = Reservation.listeDesDates(dateDebut, dateFin);
				List<String> listeDates = Arrays.asList(stringDates.split(","));
				try {
					new Planning(dateDebut, dateFin, listeDates).setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				fin.setVisible(true);
			}
		}
	}

	/**
	 * Main Affiche la premiere fenetre
	 * 
	 * @param args
	 * @throws ParseException
	 * @throws SQLException
	 */
	public static void main(String[] args) throws ParseException, SQLException {

		Fenetre fen = new Fenetre();
	}
}
