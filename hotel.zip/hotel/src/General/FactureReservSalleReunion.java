package General;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;

import Client.CompteFidelite;

public class FactureReservSalleReunion {

	int id;
	float prix;
	int remise;
	float total;

	//CONSTRUCTEUR 
	
	public FactureReservSalleReunion(int id) {
		this.id = id;
	}
	
	//SETTER
	public void setRemise(int remise) {
		this.remise = remise;
	}
	
	/**
	 * Calcul le prix de la réservation en fonction de la durée du créaneau
	 * @param reservation
	 * @return
	 * @throws SQLException
	 * @throws ParseException
	 */
	public float calculprixReservation(ReservationSalleReunion reservation) throws SQLException, ParseException {
		// retourne le prix de la reservation en fondtion de la salle reservée et de la
		// durée de la réunion
		// mettre une exception si pas validée directement dans le main
		java.lang.String sql = "SELECT prix FROM salle_reunion where id = ?  ";
		String HD = reservation.getHD();
		String HF = reservation.getHF();
		@SuppressWarnings("deprecation")

		int duree = (new Long(ReservationSalleReunion.getDureeReserv(HD, HF)).intValue());

		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		int idSalleReservee = reservation.salleReservee.getId();

		pstate.setInt(1, idSalleReservee);
		ResultSet result = pstate.executeQuery();
		result.next();
		float prix = result.getFloat("prix");
		// le prix est le prix de la chambre par heure

		this.prix = ((prix * duree) / 60);

		return this.prix;
	}
	
	/**
	 * Calcul la remise fidélité en fonction du nombre de points fidelite du cient
	 * @param compte
	 * @return
	 * @throws SQLException
	 */
	public int calculremiseFidelite(CompteFidelite compte) throws SQLException {
		// mieux de le mettre ici ou dans facture reserv salle r?
		int nb_points = compte.getNbPoints();

		int remise = nb_points / 100;
		this.setRemise(remise);
		int nb_points_a_enlever = -remise * 100;
		compte.setNbPoints(nb_points_a_enlever);
		return this.remise;

	}
	
	/**
	 * Calcul le prix total de la réservation
	 * @param reservation
	 * @param compte
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void calculprixTotal(ReservationSalleReunion reservation, CompteFidelite compte)
			throws SQLException, ParseException {
		this.total = calculprixReservation(reservation) - calculremiseFidelite(compte);
	}

	/**
	 * Ajoute la facture à la base de données
	 * @param reservation
	 * @param compte
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void ajouterFactureBDD(ReservationSalleReunion reservation, CompteFidelite compte)
			throws SQLException, ParseException {

		calculprixTotal(reservation, compte);
		System.out.println("Le client va payé" + this.total + "euros");
		java.lang.String sql = "INSERT INTO facture(id,prix,remise,total,idreserv) VALUES (?,?,?,?,?) ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id);
		pstate.setFloat(2, this.prix);
		pstate.setInt(3, this.remise);
		pstate.setFloat(4, this.total);
		pstate.setInt(5, this.id);
		pstate.executeUpdate();

	}
	
	/**
	 * Met à jour le nombre de point fidelité après avoir payé la facture
	 * @param compte
	 * @throws SQLException
	 */
	public void setPointFidelite(CompteFidelite compte) throws SQLException {
		System.out.println("2");
		float total = this.total;
		int nb_points = (int) Math.floor(total / 10);

		compte.setNbPoints(nb_points);

	}
}
