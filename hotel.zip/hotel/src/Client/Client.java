package Client;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import General.Connexion;

public class Client {
	private static int id;
	private static String nom;
	private static String prenom;
	private static int tel;
	private static String adresseMail;
	
	//CONSTRUCTEUR
	public Client () {
		
	}
	public Client(int id, String nom, String prenom, int tel, String adresseMail){
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.tel = tel;
		this.adresseMail = adresseMail;
		
	}
	
	//GETTER
	public int getId() {
		return this.id;
	} 
	
	
	/**
	 * methode qui permet de regarder si le client est dans déja dans la base de données, si il n'y est pas il est ajouté
	 * @param nom
	 * @param prenom
	 * @param tel
	 * @param adresseMail
	 * @throws SQLException
	 */
	public static void testClient(String nom, String prenom, int tel, String adresseMail) throws SQLException {
		
		int id = 0;
		java.lang.String sql = "SELECT * FROM client where nom = ? AND prenom =?  ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setString(1, nom) ;
		pstate.setString(2, prenom) ;
		ResultSet result = pstate.executeQuery(); 
		 if (result.next()) { 
			 
			System.out.println("c'est déja un client ! ");
			} else { System.out.println("le client n'est pas connu dans la BDD");
			// si il n'est pas encore dans la base de donnée on va l'ajouter
			
			//on calcul l'id du nouveau client en fonction du nombre de client déja dans la base de données
			java.lang.String sqlcount = "SELECT COUNT(*) FROM client"; 
			PreparedStatement pstatecount = Connexion.getInstance().prepareStatement(sqlcount);
			ResultSet result_count = pstatecount.executeQuery(); 
			result_count.next();
	
			id = result_count.getInt(1) +1 ;
			
			String nom_client = nom;
	
			String prenom_client = prenom;
			
			int tel_client = tel;
			
			String adresseMail_client = adresseMail;
			
			Client client = new Client(id,nom_client,prenom_client,tel_client,adresseMail_client);// on creer l'objet client
			client.ajouterClientBDD(); // on l'ajoute a la BDD
			
			client.ajouterCompteBDD();// on ajoute le compte a la BDD
			System.out.println("le nouveau client a bien été ajouté à la base de données ainsi que son compte fidelité");
	}
			}
	/**
	 * Méthode qui ajoute le client dans la BDD
	 * @throws SQLException
	 */
	public void ajouterClientBDD() throws SQLException {
			
		PreparedStatement pstate = Connexion.getInstance().prepareStatement("INSERT INTO client(id, nom, prenom, telephone, adressemail) VALUES(?,?,?,?,?)");
		pstate.setInt(1, this.id); 
		pstate.setString(2,this.nom); 
		pstate.setString(3,this.prenom); 
		pstate.setInt(4,this.tel); 
		pstate.setString(5,this.adresseMail); 
		
		pstate.executeUpdate(); // execution de la requete preparee
	}
	
	
	/**
	 * Méhode qui ajoute un nouveau compte fidélité dans la BDD
	 * @throws SQLException
	 */
	public  void ajouterCompteBDD() throws SQLException {
		
		PreparedStatement pstate = Connexion.getInstance().prepareStatement("INSERT INTO compte_fidelite(id, nbpointfidelite, idclient) VALUES(?,?,?)");
		pstate.setInt(1, this.id); 
		pstate.setInt(2,0);  //initialisation du nommbre de point à 0
		pstate.setInt(3,this.id); 
		pstate.executeUpdate(); // execution de la requete preparee
	}
	
	/**
	 * 
	 * @param nom
	 * @param prenom
	 * @return un objet client
	 * @throws SQLException
	 */	
	public static Client rechercherClient (String nom, String prenom) throws SQLException {
		// on recherche un objet client 
		//je t'expliquerai a quoi ca sert lundi 
			java.lang.String sql = "SELECT * FROM client where nom = ? AND prenom =?";
			PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
			pstate.setString(1, nom) ;
			pstate.setString(2, prenom) ;
			ResultSet result = pstate.executeQuery(); 
			
			Client client = null;
			while ( result.next())  {
				
			int id = result.getInt("id");
			
			
			String nom_client = result.getString("nom");
			String prenom_client = result.getString("prenom");
			int tel = result.getInt("telephone");
			String adresseMail = result.getString("adresseMail");
			client = new Client(id,nom_client,prenom_client,tel,adresseMail);
			System.out.println("le client a été retrouvé dans la base de données");
			
			}
			return client;
			}
	

	
	
	
}
