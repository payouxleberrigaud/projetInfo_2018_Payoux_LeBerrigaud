package Client;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import General.Connexion;


public class CompteFidelite {
	int id;
	int nb_points = 0;

	//CONSTRUCTEUR
	public CompteFidelite(int id) {
		this.id = id;
	}

	public CompteFidelite(int id, int points) {
		this.id = id;
		this.nb_points = points;
	}
	/**
	 * 
	 * @param points
	 * @throws SQLException
	 */
	
	//SETTER
	
	public void setNbPoints(int points) throws SQLException {
		this.nb_points = this.nb_points + points;

		PreparedStatement pstate = Connexion.getInstance()
				.prepareStatement("UPDATE compte_fidelite SET nbpointfidelite = ? where id = ?");
		pstate.setInt(1, this.nb_points);
		pstate.setInt(2, this.id);

		pstate.executeUpdate();
		System.out.println("Le nouveau nombre de points fidelité a été mis à jour !");
	}
	
	//GETTER
	
	public int getNbPoints() {

		return nb_points;
	}

	/**
	 * 
	 * @param idClient
	 * @return un objet CompteFidelite correspondant à celui du cient à partir de l'id du client
	 * @throws SQLException
	 */
	public static CompteFidelite rechercheCompteFidelite(int idClient) throws SQLException {
		java.lang.String sql_comptef = "SELECT * FROM compte_fidelite where id = ?";

		PreparedStatement pstate_comptef = Connexion.getInstance().prepareStatement(sql_comptef);
		pstate_comptef.setInt(1, idClient);
		ResultSet result = pstate_comptef.executeQuery();
		CompteFidelite compte = null;
		while (result.next()) {
			int id = result.getInt("id");

			int nb_points = result.getInt("nbpointfidelite");
			compte = new CompteFidelite(id, nb_points);

		}
		return compte;
	}

}
