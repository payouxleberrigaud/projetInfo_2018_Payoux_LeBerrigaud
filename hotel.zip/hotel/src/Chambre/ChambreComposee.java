package Chambre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import General.Connexion;

public class ChambreComposee {
	 int id;
	 int prix = 250 ;
	 String nom;
	 String description = (String) "cette chambre est composee d un lit double et de deux lits simples" ;
	
	 //CONSTRUCTEURS
	public ChambreComposee(int id) {
		this.id = id;	
	}
	public ChambreComposee(String nom) {
		this.nom = nom;	
	}
	
	//GETTERS
	public int getPrix(){
		return this.prix;
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * Récupération des informations sur la chambre depuis la base de données
	 * @throws SQLException
	 */
	public void getInfoChambreBDD() throws SQLException {
		java.lang.String sql = "SELECT * FROM chambre_composee where id = ? ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id); 
		ResultSet result = pstate.executeQuery(); 
		result.next();
		this.nom = result.getString("nom");
		this.prix = result.getInt("prix");
		
		
	}
	
}
