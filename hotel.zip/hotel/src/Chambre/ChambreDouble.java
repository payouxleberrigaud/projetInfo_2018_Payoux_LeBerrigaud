package Chambre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import General.Connexion;

public class ChambreDouble {

	int id;
	int prix = 150 ;
	String nom;
	String description = "d";
	
	// CONSTRUCTEUR
	public ChambreDouble(int id) {
		this.id = id;	
	}
	
	public ChambreDouble(String nom) {
		this.nom = nom;	
	}
	
	// GETTERS
	public int getPrix(){
		return this.prix;
	}
	
	public int getId() {
		return this.id;
	}
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * Récupération des information sur la chambre depuis la base de données
	 **/
	public void getInfoChambreBDD() throws SQLException {
		java.lang.String sql = "SELECT * FROM chambre_double where id = ? ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id); 
		ResultSet result = pstate.executeQuery(); 
		result.next();
		this.nom = result.getString("nom");
		this.prix = result.getInt("prix");	
		
	}
	
	
	
}
