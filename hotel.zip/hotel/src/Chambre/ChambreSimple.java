package Chambre;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import General.Connexion;

public class ChambreSimple {
	private int id;
	private int prix = 100 ;
	private String nom;
	private String description ="dd";
	
	//CONSTRUCTEURS
	public ChambreSimple(int id) {
		this.id = id;
		
	}	
	public ChambreSimple(String nom) {
		this.nom = nom;
			
	}
	
	//GETTERS
	public int getPrix(){
		return this.prix;
	}
	
	public int getId() {
		return this.id;
	}
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * Récupére les informations sur la chambre depuis la base de données
	 * @throws SQLException
	 */
	public void getInfoChambreBDD() throws SQLException {
		java.lang.String sql = "SELECT * FROM chambre_simple where id = ? ";
		PreparedStatement pstate = Connexion.getInstance().prepareStatement(sql);
		pstate.setInt(1, this.id); 
		ResultSet result = pstate.executeQuery(); 
		result.next();
		this.nom = result.getString("nom");
		this.prix = result.getInt("prix");
		
	}
	
	
}
